SELECT 
advisor_id as "stakeholder_id",
first_name,
last_name,
"advisor" as stakeholder
FROM 
advisor
union
SELECT 
investor_id as"stakeholder_id",
first_name,
last_name,
"investor" as stakeholder
from
investor;
