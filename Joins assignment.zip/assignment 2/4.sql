SELECT 
a.store_id,b.rating,
count(a.film_id),
avg(b.replacement_cost),
sum(b.replacement_cost)
from inventory as a
left join film as b
on a.film_id=b.film_id
group by
a.store_id,b.rating;