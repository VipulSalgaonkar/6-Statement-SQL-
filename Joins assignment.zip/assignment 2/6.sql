SELECT 
a.customer_id,
a.first_name,a.last_name,sum(b.amount)
from customer as a
left join payment as b
on a.customer_id=b.customer_id
group by a.customer_id
order by sum(b.amount) desc;