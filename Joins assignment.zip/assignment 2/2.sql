SELECT 
inventory.inventory_id,inventory.store_id,
film.title,film.rating,film.rental_rate,film.replacement_cost
from inventory
left join film
on film.film_id=inventory.film_id;