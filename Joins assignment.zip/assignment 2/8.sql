SELECT 
b.awards,count(a.actor_id)
from actor as a
left join actor_award as b
on a.actor_id=b.actor_id
group by b.awards;