SELECT 
a.customer_id,a.store_id,a.first_name,a.last_name,a.active,b.address,c.city,d.country
from customer as a
left join address as b
on a.address_id=b.address_id
left join city as c
on b.city_id=c.city_id
left join country as d
on c.country_id=d.country_id;