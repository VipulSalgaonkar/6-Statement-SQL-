
SELECT  
b.rating,
count(b.film_id),
 a.inventory_id, a.store_id,b.film_id,
b.title ,b.rental_rate,b.replacement_cost
from inventory as a
left join film as b
on a.film_id=b.film_id
group by b.rating;
