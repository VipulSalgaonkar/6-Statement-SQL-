SELECT * FROM mavenmovies.staff;
-- list of all staff member alonng with name, last name , email , store id where they work

select 
staff_id,
first_name,
last_name,
email,
store_id
 from staff;
 
 
 
 -- we will need seperate count of inventory items held at each two store
 
 select * from inventory;
 
 select count(inventory_id) from inventory ;
 
 -- we will need oa count of active customer for each store 
 
 select * from customer;
 select count(active) from customer
 where active = '1';
 
 -- in order to access the liability of data breach,we will need you to provide a count of all customer email address store  in database
 
 select * from customer;
 select count(email) from  customer;
 
 
 -- 5. provide count of unique film titles you have in inventory at each store
 select 
 distinct title
 from film;
 select count(title) from film; 
 
 
 -- provide a count of unique categories of film 
 select 
	distinct name
from category;
select count(name) from category;

-- we would like to understand the replacement cost of your films.please provide the replacement cost for the film that is least expensive to replace,most expensive & average of all films
select replacement_cost
from film
where replacement_cost  ;

select 
	title,
	min(replacement_cost)as Minimum_Replacement_Cost,
	max(replacement_cost) as Maximum_Replacement_Cost,
	avg(replacement_cost)
	from film
	group by title
	order by min(replacement_cost);



select 
	title,
	max(replacement_cost) as Maximum_Replacement_Cost,
	avg(replacement_cost)
	from film
	group by title
	order by min(replacement_cost);
 
 select 
	title,
	min(replacement_cost)as Minimum_Replacement_Cost
	from film
	group by title
	order by min(replacement_cost);
    
    select 
	title,

	avg(replacement_cost)
	from film
	group by title
	order by avg(replacement_cost);
    
    
    
    -- provide avg payment as well as maximum payment 
    
    select
    staff_id,
    avg(amount),
    max(amount)
    from payment
    group by staff_id
    order by avg(amount),
    max(amount);
    
    
    -- Provide list of customer with id  and count of rental in desc order
    
    Select 
    customer_id,
    count(rental_id)
    from rental
    group by customer_id
    order by count(rental_id) desc;
 
 